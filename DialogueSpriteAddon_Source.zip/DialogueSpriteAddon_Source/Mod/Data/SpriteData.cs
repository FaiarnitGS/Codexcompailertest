namespace DialogueSpriteAddon
{
    // JSON property names intentionally match the old DDF sprite configuration.
    internal sealed class SpriteData
    {
        public int xOffset { get; set; } = 0;
        public int yOffset { get; set; } = 0;
        public bool right { get; set; } = false;
        public bool bottom { get; set; } = false;
        public float scale { get; set; } = 4f;
        public float layerDepth { get; set; } = 0.88f;
        public bool disabled { get; set; } = false;
        public bool background { get; set; } = false;
        // -1 = animate; >= 0 = fixed frame.
        public int frame { get; set; } = -1;
    }
}
