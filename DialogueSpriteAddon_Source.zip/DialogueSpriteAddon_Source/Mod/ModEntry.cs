using DialogueDisplayFramework;
using DialogueSpriteAddon.Rendering;
using StardewModdingAPI;
using StardewModdingAPI.Events;
using System;

namespace DialogueSpriteAddon
{
    internal sealed class ModEntry : Mod
    {
        internal static IModHelper ModHelper;
        internal static IMonitor ModMonitor;
        internal static SpriteDataManager SpriteData;
        private IDialogueDisplayApi ddfApi;

        public override void Entry(IModHelper helper)
        {
            ModHelper = helper;
            ModMonitor = Monitor;
            SpriteData = new SpriteDataManager(helper);
            helper.Events.GameLoop.GameLaunched += OnGameLaunched;
        }

        private void OnGameLaunched(object sender, GameLaunchedEventArgs e)
        {
            try
            {
                ddfApi = Helper.ModRegistry.GetApi<IDialogueDisplayApi>(
                    "Mangupix.DialogueDisplayFrameworkContinued");
                if (ddfApi == null)
                {
                    Monitor.Log("DDFC API unavailable; sprite rendering is disabled.", LogLevel.Warn);
                    return;
                }
                ddfApi.RenderedPortrait += SpriteRenderer.OnRenderedPortrait;
                Monitor.Log("Connected to DDFC API.", LogLevel.Info);
            }
            catch (Exception ex)
            {
                Monitor.Log($"Failed to connect to DDFC API: {ex}", LogLevel.Error);
            }
        }
    }
}
