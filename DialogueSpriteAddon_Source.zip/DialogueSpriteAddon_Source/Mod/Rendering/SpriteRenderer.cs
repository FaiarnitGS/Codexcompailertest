using HarmonyLib;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using StardewValley;
using StardewValley.BellsAndWhistles;
using StardewValley.Characters;
using StardewValley.Menus;
using System;
using System.Collections.Generic;
using DialogueDisplayFramework;

namespace DialogueSpriteAddon.Rendering
{
    // Draws the legacy sprite after DDFC's portrait render event.
    internal static class SpriteRenderer
    {
        private static ProfileMenu spriteMenu;
        private static string currentNpcName;
        private static AnimatedSprite animatedSprite;

        internal static void OnRenderedPortrait(object sender, IRenderEventArgs<IPortraitData> args)
        {
            try
            {
                if (args?.DialogueBox?.characterDialogue?.speaker is not NPC npc)
                    return;

                Dictionary<string, SpriteData> entries = ModEntry.SpriteData.GetData();
                if (entries == null)
                    return;

                SpriteData sprite = entries.TryGetValue(npc.Name, out var npcData)
                    ? npcData
                    : (entries.TryGetValue("default", out var fallback) ? fallback : null);

                if (sprite == null || sprite.disabled)
                    return;

                EnsureSpriteMenu(npc);
                if (spriteMenu == null || animatedSprite == null)
                    return;

                DialogueBox box = args.DialogueBox;
                Vector2 pos = GetDataVector(box, sprite);

                if (sprite.background)
                    args.SpriteBatch.Draw(
                        Game1.timeOfDay >= 1900 ? Game1.nightbg : Game1.daybg,
                        pos, Color.White);

                if (sprite.frame >= 0)
                    animatedSprite.CurrentFrame = sprite.frame;
                else
                    spriteMenu.update(Game1.currentGameTime);

                animatedSprite.draw(
                    args.SpriteBatch, pos + new Vector2(32, 32),
                    sprite.layerDepth, 0, 0, Color.White,
                    false, sprite.scale, 0, false);
            }
            catch (Exception ex)
            {
                ModEntry.ModMonitor.Log($"Error drawing dialogue sprite: {ex}",
                    StardewModdingAPI.LogLevel.Error);
            }
        }

        private static void EnsureSpriteMenu(NPC npc)
        {
            if (spriteMenu != null && currentNpcName == npc.Name)
                return;

            try
            {
                Game1.player.friendshipData.TryGetValue(npc.Name, out var friendship);
                spriteMenu = new ProfileMenu(
                    new SocialPage.SocialEntry(npc, friendship, null, npc.displayName),
                    new SocialPage(0, 0, 0, 0).FindSocialCharacters());

                animatedSprite = AccessTools.FieldRefAccess<ProfileMenu, AnimatedSprite>(
                    spriteMenu, "_animatedSprite");
                currentNpcName = npc.Name;
            }
            catch (Exception ex)
            {
                spriteMenu = null;
                animatedSprite = null;
                currentNpcName = null;
                ModEntry.ModMonitor.Log($"Could not create sprite menu for {npc.Name}: {ex}",
                    StardewModdingAPI.LogLevel.Warn);
            }
        }

        private static Vector2 GetDataVector(DialogueBox box, SpriteData data)
        {
            return new Vector2(
                box.x + (data.right ? box.width : 0) + data.xOffset,
                box.y + (data.bottom ? box.height : 0) + data.yOffset);
        }
    }
}
