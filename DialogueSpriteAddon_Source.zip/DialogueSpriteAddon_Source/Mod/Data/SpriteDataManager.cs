using StardewModdingAPI;
using StardewModdingAPI.Events;
using System.Collections.Generic;

namespace DialogueSpriteAddon
{
    // Provides a separate custom asset that Content Patcher can edit.
    internal sealed class SpriteDataManager
    {
        internal const string AssetName = "DialogueSpriteAddon/sprites";
        private readonly IModHelper helper;

        internal SpriteDataManager(IModHelper helper)
        {
            this.helper = helper;
            helper.Events.Content.AssetRequested += OnAssetRequested;
        }

        private void OnAssetRequested(object sender, AssetRequestedEventArgs e)
        {
            if (!e.Name.IsEquivalentTo(AssetName))
                return;

            e.LoadFrom(
                () => helper.Data.ReadJsonFile<Dictionary<string, SpriteData>>("assets/sprites.json")
                    ?? new Dictionary<string, SpriteData>(),
                AssetLoadPriority.Exclusive);
        }

        internal Dictionary<string, SpriteData> GetData()
        {
            return helper.GameContent.Load<Dictionary<string, SpriteData>>(AssetName);
        }
    }
}
