# Technical review notes

- DDFC API used: `IDialogueDisplayApi`, `IRenderEventArgs<IPortraitData>`, `RenderedPortrait`.
- The public API types are in DDFC's root `DialogueDisplayFramework` namespace.
- Sprite config is stored in this add-on's own `DialogueSpriteAddon/sprites` asset, because Continued removed sprite data from its dictionary.
- The rendering code follows original DDF's ProfileMenu / private `_animatedSprite` approach and uses Harmony reflection.
- `RenderedPortrait` is called after DDFC draws its portrait, so this add-on renders after it.

Before compiling/testing:
1. Add correct local references in the csproj.
2. Verify the exact DDFC API DLL exposes the event and generic types as pasted.
3. Verify Stardew 1.6 Android's ProfileMenu constructor and `_animatedSprite` field.
4. Test SMAPI custom asset loading and CP `EditData`.
5. Test positioning and draw order in game.
6. The manifest UniqueID is a placeholder and must be changed before release.
