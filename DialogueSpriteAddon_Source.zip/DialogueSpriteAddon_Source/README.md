# Dialogue Sprite Addon
Separate SMAPI add-on source scaffold restoring the legacy DDF sprite rendering for DDFC Continued.

Status: source scaffold only; not compiled or tested in-game/Android.

Requirements: Stardew Valley 1.6, SMAPI, Dialogue Display Framework Continued, Content Patcher (optional config pack).

Before release, replace `ExampleAuthor.DialogueSpriteAddon` with your own UniqueID and add local references to Stardew Valley, SMAPI, Harmony, and MonoGame/XNA assemblies to the csproj.

Folders:
- Mod/: C# SMAPI mod source
- ContentPack/: example CP pack
- docs/: implementation notes

The add-on loads its own asset `DialogueSpriteAddon/sprites`; CP edits that asset, not DDFC's dictionary. `frame: -1` animates; nonnegative frame fixes the sprite frame.
